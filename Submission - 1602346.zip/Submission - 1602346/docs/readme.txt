A simple game, where the player controls a pirate ship.
Control your ship by clicking the mouse. Ship will move towards 
mouse position for as long as the left mouse button is down.

The game was created using sfml version 2.4.0
https://www.sfml-dev.org/download/sfml/2.4.0/

